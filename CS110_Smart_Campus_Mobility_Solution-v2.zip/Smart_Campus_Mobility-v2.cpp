#include <iostream>
#include <cmath>
using namespace std;

// Function Prototypes
void showMenu();
bool isValidChoice(int choice, int minVal, int maxVal);
bool hasEnoughBalance(double balance, double totalFare);
double calculateBaseFare(int vehicle_choice, int billedMinutes);
double calculatePeakSurcharge(double baseFare, int startHour);
double calculateMemberDiscount(double fareAfterPeak, char memberChoice);
double calculateSafetyPenalty(int vehicle_choice, char helmetChoice);
double calculateParkingPenalty(int parkingZone);
double calculateFinalRideCost(int vehicle_choice, double minutes, int startHour,
                              char memberChoice, char helmetChoice, int parkingZone,
                              int &billedMinutes, double &baseFare,
                              double &surcharge, double &discount, double &penalties);
void addFunds(double &balance);
void updateWalletAndStats(double &balance, int &totalRides, double &totalSpent, double finalFare);
void showReceipt(int vehicle_choice, int billedMinutes, double baseFare,
                 double surcharge, double discount, double penalties,
                 double finalFare, double balance);
void showStatistics(double balance, int totalRides, double totalSpent);

int main()
{
    int choice;
    double balance = 0, totalSpent = 0;
    int totalRides = 0;

    do
    {
        showMenu();
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            addFunds(balance);
            break;
        }
        case 2:
        {
            int vehicle_choice, startHour, parkingZone;
            double minutes;
            char memberChoice, helmetChoice = 'Y';

            cout << "\n====== Select Vehicle ======" << endl;
            cout << "1. Bicycle = Rs. 50 + Rs. 4/min" << endl;
            cout << "2. E-Scooter = Rs. 80 + Rs. 7/min" << endl;
            cout << "3. E-Bike = Rs. 100 + Rs. 9/min" << endl;
            cout << "Enter your choice: ";
            cin >> vehicle_choice;

            if (!isValidChoice(vehicle_choice, 1, 3))
            {
                cout << "Invalid vehicle choice!" << endl;
                break;
            }

            cout << "Enter ride duration in minutes: ";
            cin >> minutes;
            if (minutes <= 0)
            {
                cout << "Invalid Duration Amount!" << endl;
                break;
            }

            cout << "Enter ride start hour (0-23): ";
            cin >> startHour;
            if (!isValidChoice(startHour, 0, 23))
            {
                cout << "Invalid start hour! Must be between 0 and 23." << endl;
                break;
            }

            cout << "Are you a student member? (Y/N): ";
            cin >> memberChoice;

            if (vehicle_choice == 2 || vehicle_choice == 3)
            {
                cout << "Did you wear a helmet? (Y/N): ";
                cin >> helmetChoice;
            }

            cout << "Select Parking Zone (1 = Green, 2 = Yellow, 3 = Red): ";
            cin >> parkingZone;
            if (!isValidChoice(parkingZone, 1, 3))
            {
                cout << "Invalid parking zone!" << endl;
                break;
            }

            int billedMinutes = 0;
            double baseFare = 0, surcharge = 0, discount = 0, penalties = 0;

            // Calls modular calculation function
            double finalFare = calculateFinalRideCost(
                vehicle_choice, minutes, startHour, memberChoice, helmetChoice, parkingZone,
                billedMinutes, baseFare, surcharge, discount, penalties
            );

            // Check wallet before completing ride
            if (hasEnoughBalance(balance, finalFare))
            {
                updateWalletAndStats(balance, totalRides, totalSpent, finalFare);
                showReceipt(vehicle_choice, billedMinutes, baseFare, surcharge,
                            discount, penalties, finalFare, balance);
            }
            else
            {
                cout << "\nInsufficient wallet balance! Payment rejected." << endl;
                cout << "Required Fare: Rs. " << finalFare << " | Current Balance: Rs. " << balance << endl;
            }
            break;
        }
        case 3:
        {
            showStatistics(balance, totalRides, totalSpent);
            break;
        }
        case 4:
        {
            cout << "Exiting Ride Booking System. Goodbye!" << endl;
            break;
        }
        default:
        {
            cout << "Invalid menu choice! Please enter 1 to 4." << endl;
            break;
        }
        }

    } while (choice != 4);

    return 0;
}

// Displays main menu
void showMenu()
{
    cout << "\n===== RIDE BOOKING SYSTEM =====" << endl;
    cout << "1. Add Funds" << endl;
    cout << "2. Start a Ride" << endl;
    cout << "3. View Wallet/Ride Statistics" << endl;
    cout << "4. Exit" << endl;
}

// Checks if an integer input is within valid range [minVal, maxVal]
bool isValidChoice(int choice, int minVal, int maxVal)
{
    if (choice >= minVal && choice <= maxVal)
        return true;
    else
        return false;
}

// Checks if user wallet has enough money for the ride
bool hasEnoughBalance(double balance, double totalFare)
{
    if (balance >= totalFare)
        return true;
    else
        return false;
}

// Calculates base fare using unlock fee and billed minutes
double calculateBaseFare(int vehicle_choice, int billedMinutes)
{
    double unlock = 0, rate = 0;

    switch (vehicle_choice)
    {
    case 1:
        unlock = 50;
        rate = 4;
        break;
    case 2:
        unlock = 80;
        rate = 7;
        break;
    case 3:
        unlock = 100;
        rate = 9;
        break;
    }

    return unlock + (billedMinutes * rate);
}

// Applies 15% peak surcharge if startHour is between 8-10 or 16-18 inclusive
double calculatePeakSurcharge(double baseFare, int startHour)
{
    if ((startHour >= 8 && startHour <= 10) || (startHour >= 16 && startHour <= 18))
        return baseFare * 0.15;
    else
        return 0;
}

// Applies 10% student member discount on ride fare after surcharge
double calculateMemberDiscount(double fareAfterPeak, char memberChoice)
{
    if (memberChoice == 'Y' || memberChoice == 'y')
        return fareAfterPeak * 0.10;
    else
        return 0;
}

// Adds Rs. 150 penalty if riding E-Scooter or E-Bike without a helmet
double calculateSafetyPenalty(int vehicle_choice, char helmetChoice)
{
    if ((vehicle_choice == 2 || vehicle_choice == 3) && (helmetChoice == 'N' || helmetChoice == 'n'))
        return 150;
    else
        return 0;
}

// Calculates parking penalty: Green = 0, Yellow = 50, Red = 200
double calculateParkingPenalty(int parkingZone)
{
    switch (parkingZone)
    {
    case 1:
        return 0;
    case 2:
        return 50;
    case 3:
        return 200;
    default:
        return 0;
    }
}

// Main fare coordinator function that calls other user-defined functions
double calculateFinalRideCost(int vehicle_choice, double minutes, int startHour,
                              char memberChoice, char helmetChoice, int parkingZone,
                              int &billedMinutes, double &baseFare,
                              double &surcharge, double &discount, double &penalties)
{
    // ceil() from <cmath> rounds partial minutes up to the next full minute
    billedMinutes = ceil(minutes);

    baseFare = calculateBaseFare(vehicle_choice, billedMinutes);
    surcharge = calculatePeakSurcharge(baseFare, startHour);

    double fareAfterPeak = baseFare + surcharge;
    discount = calculateMemberDiscount(fareAfterPeak, memberChoice);

    // Safety and parking penalties are NOT discounted
    penalties = calculateSafetyPenalty(vehicle_choice, helmetChoice) + calculateParkingPenalty(parkingZone);

    return (fareAfterPeak - discount) + penalties;
}

// Adds valid funds to user wallet using pass-by-reference
void addFunds(double &balance)
{
    double amount;
    cout << "Enter amount to add: ";
    cin >> amount;

    if (amount > 0)
    {
        balance += amount;
        cout << "Funds Added Successfully! Current Balance: Rs. " << balance << endl;
    }
    else
    {
        cout << "Invalid amount! Please enter a positive value." << endl;
    }
}

// Updates balance and ride statistics via pass-by-reference after payment
void updateWalletAndStats(double &balance, int &totalRides, double &totalSpent, double finalFare)
{
    balance -= finalFare;
    totalRides++;
    totalSpent += finalFare;
}

// Displays itemized ride receipt
void showReceipt(int vehicle_choice, int billedMinutes, double baseFare,
                 double surcharge, double discount, double penalties,
                 double finalFare, double balance)
{
    cout << "\n===== RIDE RECEIPT =====" << endl;
    cout << "Vehicle: ";
    if (vehicle_choice == 1)
        cout << "Bicycle" << endl;
    else if (vehicle_choice == 2)
        cout << "E-Scooter" << endl;
    else
        cout << "E-Bike" << endl;

    cout << "Billed Minutes: " << billedMinutes << endl;
    cout << "Base Ride Fare: Rs. " << baseFare << endl;
    cout << "Peak Surcharge: Rs. " << surcharge << endl;
    cout << "Student Discount: -Rs. " << discount << endl;
    cout << "Safety/Parking Penalties: Rs. " << penalties << endl;
    cout << "Final Amount Paid: Rs. " << finalFare << endl;
    cout << "Remaining Wallet Balance: Rs. " << balance << endl;
    cout << "========================" << endl;
}

// Displays current wallet and trip statistics
void showStatistics(double balance, int totalRides, double totalSpent)
{
    cout << "\n===== WALLET STATISTICS =====" << endl;
    cout << "Current Balance: Rs. " << balance << endl;
    cout << "Total Rides: " << totalRides << endl;
    cout << "Total Amount Spent: Rs. " << totalSpent << endl;
}
